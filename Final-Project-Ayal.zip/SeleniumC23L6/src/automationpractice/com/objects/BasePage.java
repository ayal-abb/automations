package automationpractice.com.objects;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
public class BasePage {
	protected WebDriver driver;
	public BasePage(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	public void click(WebElement el) {	
		el.click();
	}
	public void fillText(WebElement el , String text) {
		el.clear();
		el.sendKeys(text);
	}
	public String getText(WebElement el) {

		return el.getText();
	}
	public void sleep(long milsec) {
		try {
			Thread.sleep(milsec);
		} catch (InterruptedException e) {
			e.printStackTrace() ;
		}
	}
}