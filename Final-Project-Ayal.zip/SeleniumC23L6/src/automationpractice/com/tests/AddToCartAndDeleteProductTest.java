package automationpractice.com.tests;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.Test;

import automationpractice.com.addtocart.AddToCartPage;
import automationpractice.com.addtocart.DeleteProductPage;
public class AddToCartAndDeleteProductTest extends BaseTest{
	@Test(description="Add an item")
	public void A01_AddToCartTest (){
		/*
		1.Select the first option by clicking add to cart and then clicking PROCCED to checkout
		 */	
		AddToCartPage ac = new AddToCartPage(driver);
		ac.sleep(2000);
		ac.ToCart(0);
		ac.sleep(1000);
	}	
	@Test(description="Add quantity")
	public void A02_AddQuantity (){
		DeleteProductPage dp = new DeleteProductPage(driver);	
		//Add quantity
		dp.AddQuantityInTheProduc();
	}
	@Test
	public void A03_DeleteProduct (){	
		/*
		1.Remove the item
		2.Error Message Your shopping cart is empty
		 */
		DeleteProductPage dp = new DeleteProductPage(driver);
		dp.sleep(1000);
		dp.DeleteProduct();
		dp.sleep(2000);
		Assert.assertEquals(dp.errorMsg(),"Your shopping cart is empty.");
	}
}