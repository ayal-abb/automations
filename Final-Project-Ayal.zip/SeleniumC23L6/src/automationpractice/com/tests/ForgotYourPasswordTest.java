package automationpractice.com.tests;
import org.testng.Assert;
import org.testng.annotations.Test;
import automationpractice.com.createanaccount.ForgotYourPasswordPage;
import automationpractice.com.createanaccount.HomePage;
public class ForgotYourPasswordTest extends BaseTest{
	@Test(description="I forgot the password")
	public void A01_ForgotYourPassword(){
		/*
		1.Click to sign in
		2.Forgot password
		3.Reset your email
		4.Error message
		 */
		HomePage hp = new HomePage(driver);
		hp.ClickOnSignIn();
		hp.sleep(3000);
		
		ForgotYourPasswordPage fy = new ForgotYourPasswordPage(driver);
		fy.sleep(1000);
		fy.ForgotYourPass();
		fy.sleep(1000);
		fy.EmailAddress("aele4321@gmail.com");
		fy.clickRetrivePass();
		Assert.assertEquals(fy.errorMsg(),"A confirmation email has been sent to your address: aele4321@gmail.com");
	}
}