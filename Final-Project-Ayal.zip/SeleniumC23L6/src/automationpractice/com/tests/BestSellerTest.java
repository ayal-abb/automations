package automationpractice.com.tests;
import org.testng.Assert;
import org.testng.annotations.Test;
import automationpractice.com.bestseller.BestSellerPage;
import automationpractice.com.bestseller.ContinueBuyTheProductPage;
import automationpractice.com.bestseller.SelectProductBestSellerPage;
public class BestSellerTest extends BaseTest{
	@Test(description="Buy a dress")
	public void A01_BuyaDress(){
		/*
		1.Click on a bestseller feature in the home browser
		2.Move the mouse without a picture
		3.Click Add Product
		4.To proceed to checkout
		4.Click Terms Of Service And Proceed
		5.Pay By Check
		6.Confirm My Order
		7.Message Your order on My Store is complete
		*/
		BestSellerPage bs = new BestSellerPage(driver);
		bs.clickBestSeller();
		bs.sleep(2000);
		SelectProductBestSellerPage sp = new SelectProductBestSellerPage(driver);
		sp.sleep(2000);
		sp.select();
		sp.sleep(2000);
		sp.ToTheCart(0);
		sp.sleep(2000);
		sp.ProceedToCheckOut();

		ContinueBuyTheProductPage cb = new ContinueBuyTheProductPage(driver);
		cb.ContinueProceedBuyProduct();
		cb.EmailAddress("aele4321@gmail.com", "qazwsx123");
		cb.AddAResponseToTheInvitation("Hi when is more or less coming to the invitation?");
		cb.sleep(1000);
		cb.ProceedToCheckOut();
		cb.sleep(1000);
		cb.clickTermsOfServiceAndProceed(); 
		cb.sleep(1500);
		cb.PayBuyCheck();
		cb.sleep(1000);
		cb.ConfirmMyOrder();
		cb.sleep(1000);
		Assert.assertEquals(cb.OrderMsgIsComplete(), "Your order on My Store is complete.");    
	}
}