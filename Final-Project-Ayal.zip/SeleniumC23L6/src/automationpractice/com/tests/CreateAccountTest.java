package automationpractice.com.tests;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;
import org.testng.annotations.Test;
import automationpractice.com.createanaccount.CreateAccountPage;
import automationpractice.com.createanaccount.ForgotYourPasswordPage;
import automationpractice.com.createanaccount.HomePage;
public class CreateAccountTest extends BaseTest{
	@Test(description="create fail account")
	public void A01Create_fail_account() throws InterruptedException{
		//click on sign in
		////account creation
		//error message
		HomePage hp = new HomePage(driver);
		hp.ClickOnSignIn();
		hp.sleep(3000);

		CreateAccountPage ca = new CreateAccountPage(driver);
		ca.CreateAccount("aele4321@gmail.com");
		ca.sleep(1000);
		Assert.assertEquals(ca.errorMsg(), "An account using this email address has already been registered. Please enter a valid password or request a new one.");	
	}	
	@Test(description="create empty account")
	public void A02Create_Empty_account() throws InterruptedException{	
		/*
		1. empty 
		2.error message
		 */	
		CreateAccountPage ca = new CreateAccountPage(driver);
		ca.CreateAccount("");
		ca.sleep(3000);
		Assert.assertEquals(ca.errorMsg(), "Invalid email address.");	
	}
	@Test(description="create bad account")
	public void A03Create_Bad_account() throws InterruptedException{	
		/*
		1.Create the wrong account
	    2.Invalid email address
		 */
		CreateAccountPage ca = new CreateAccountPage(driver);
		ca.CreateAccount("$FWFWEFW");
		ca.sleep(3000);
		Assert.assertEquals(ca.errorMsg(), "Invalid email address.");	
	}
}