package automationpractice.com.tests;
import static org.testng.Assert.assertEquals;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.SendKeysAction;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.Assertion;
import automationpractice.com.contact.us.ContactUsPage;
import automationpractice.com.contact.us.SendAMessagePage;
import automationpractice.com.objects.BasePage;
public class ContactUsTest extends BaseTest{
	@Test(description="Contact")
	public void A01_OpenToContactUs()throws InterruptedException{
		//waiting
		//click to open contactUs	
		ContactUsPage cu = new ContactUsPage(driver);	
		cu.sleep(2000);
		cu.ClickOnContactUs();
		cu.sleep(2000);
	}
	@Test(description="Choose from the list")
	public void A02_ContactUs_Choose_The_choice_was_successful(){
		/*
		1.Select from list
		2.waiting
		3.Register email
		4.Register an order number
		5.click to send
		6.error message
		 */
		SendAMessagePage sm = new SendAMessagePage(driver);
		sm.sleep(2000);
		sm.Choose();
		sm.sleep(2000);
		sm.email("aele4321@gmail.com");
		sm.sleep(1000);
		sm.OrderReference("55623");
		sm.sleep(1000);
		sm.Message("I hope they made contact");
		sm.btnClickSend();
		Assert.assertEquals(sm.errorMsg(),"Your message has been successfully sent to our team.");
	}
}