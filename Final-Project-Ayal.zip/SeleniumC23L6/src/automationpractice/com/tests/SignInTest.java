package automationpractice.com.tests;
import org.testng.Assert;
import org.testng.annotations.Test;
import automationpractice.com.createanaccount.CreateAccountPage;
import automationpractice.com.createanaccount.ForgotYourPasswordPage;
import automationpractice.com.createanaccount.HomePage;
import automationpractice.com.createanaccount.SignInPage;
public class SignInTest extends BaseTest{
	@Test(description="Register email and password")
	public void A01_SignIn(){
		/*
		1.Click to sign in
		2.Register email address 
		3.Register password
		4.Error message Failure to accept credit slips
		 */
		HomePage hp = new HomePage(driver);
		hp.ClickOnSignIn();
		hp.sleep(3000);

		SignInPage si = new SignInPage(driver);
		si.EmailAddress("aele4321@gmail.com", "qazwsx123");
		Assert.assertEquals(si.ErrorMessage(),"You have not received any credit slips.");
	}
}