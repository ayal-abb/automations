package automationpractice.com.createanaccount;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import automationpractice.com.objects.BasePage;
public class ForgotYourPasswordPage extends BasePage{
	@FindBy(css=".lost_password.form-group a")
	WebElement btnForgotPass;
	@FindBy(css="#email")
	WebElement fdForgotEmailAddress;
	@FindBy(css=".submit span")
	WebElement btnRetrivePass;
	@FindBy(css=".alert.alert-success")
	WebElement msgErroremail;
	public ForgotYourPasswordPage(WebDriver driver){
		super(driver);
	}
	public void ForgotYourPass(){
		click(btnForgotPass);
	}
	public void EmailAddress(String email){
		fillText(fdForgotEmailAddress, email);
	}
	public void clickRetrivePass(){
		click(btnRetrivePass);
	}
	public String errorMsg(){
		return getText(msgErroremail);  
	}
}