package automationpractice.com.createanaccount;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import automationpractice.com.objects.BasePage;
public class SignInPage extends BasePage {
	@FindBy(css="#email")
	WebElement fdEmailAddress;
	@FindBy(css="#passwd")
	WebElement fdPassword;
	@FindBy(css="#SubmitLogin")
	WebElement btnSignIn;
	@FindBy(css="[title='Credit slips'] span")
	WebElement clickCreditSlips;
	@FindBy(css=".alert.alert-warning")
	WebElement Errormsg;
	@FindBy(css="#authentication")
	WebElement ErrorMsgAuthenticationFailed;
	public SignInPage(WebDriver driver) {
		super(driver);
	}
	public void EmailAddress(String email,String password){
		fillText(fdEmailAddress, email);
		fillText(fdPassword, password);
		click(btnSignIn);
		click(clickCreditSlips);
	}
	public String ErrorMessage(){
		return getText(Errormsg);
	}
}