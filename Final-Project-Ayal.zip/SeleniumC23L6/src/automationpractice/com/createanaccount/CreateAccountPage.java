package automationpractice.com.createanaccount;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import automationpractice.com.objects.BasePage;
public class CreateAccountPage extends BasePage{
	@FindBy(css = "#email_create")
	WebElement fdCreateEmail;
	@FindBy(css = ".icon-user.left")
	WebElement btnCreateAccount;
	@FindBy(css = ".alert.alert-danger>ol>li")
	WebElement msgErrorCreateAccount;
	public CreateAccountPage(WebDriver driver){
		super(driver);	
	}
	public void CreateAccount(String email){
		fillText(fdCreateEmail, email);
		click(btnCreateAccount);
	}
	public String errorMsg(){
		return getText(msgErrorCreateAccount);
	}
}