package automationpractice.com.createanaccount;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import automationpractice.com.objects.BasePage;
public class HomePage extends BasePage{
	@FindBy(css=".login")
	WebElement btnSignIn;
	public HomePage(WebDriver driver){
		super(driver);
	}
	public void ClickOnSignIn(){
		click(btnSignIn);
	}
}