package automationpractice.com.bestseller;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import automationpractice.com.objects.BasePage;
public class ContinueBuyTheProductPage extends BasePage {
	@FindBy(css=".button.btn.btn-default.standard-checkout.button-medium>span")
	WebElement btnContinueBuy;
	@FindBy(css="#email")
	WebElement fdEmailAddress;
	@FindBy(css="#passwd")
	WebElement fdPassword;
	@FindBy(css="#SubmitLogin")
	WebElement btnLoginSignIn;
	@FindBy(css="[name='message']")
	WebElement fdAddAResponseToTheInvitation;
	@FindBy(css="[name='processAddress']>span")
	WebElement btnProceedToCheckout;
	@FindBy(css="#uniform-cgv>span")
	WebElement clickTermsOfService;
	@FindBy(css="[name='processCarrier']>span")
	WebElement ProceedToCheckOut;
	@FindBy(css=".cheque>span")
	WebElement btnPayByCheck;
	@FindBy(css="button.btn.btn-default.button-medium span")
	WebElement btnConfirmMyOrder;
	@FindBy(css=".alert.alert-success")
	WebElement MsgIsComplete;
	public ContinueBuyTheProductPage(WebDriver driver) {
		super(driver);	
	}
	public void ContinueProceedBuyProduct(){
		click(btnContinueBuy);
	}
	public void EmailAddress(String email,String password){
		fillText(fdEmailAddress, email);
		fillText(fdPassword, password);
		click(btnLoginSignIn);
	}
	public void AddAResponseToTheInvitation(String message){
		fillText(fdAddAResponseToTheInvitation, message);
	}
	public void ProceedToCheckOut(){
		click(btnProceedToCheckout);
	}
	public void clickTermsOfServiceAndProceed(){
		click(clickTermsOfService);
		click(ProceedToCheckOut);
	}
	public void PayBuyCheck(){
		click(btnPayByCheck);
	}
	public void ConfirmMyOrder(){
		click(btnConfirmMyOrder);
	}
	public String OrderMsgIsComplete(){
		return getText(MsgIsComplete);
	}
}