package automationpractice.com.bestseller;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import automationpractice.com.objects.BasePage;

public class BestSellerPage extends BasePage {
	@FindBy(css="[title='Best sellers']")
	WebElement btnBestSeller;
	public BestSellerPage(WebDriver driver) {
		super(driver);

	}
	public void clickBestSeller(){
		click(btnBestSeller);
	}
}