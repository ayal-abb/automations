package automationpractice.com.bestseller;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;
import automationpractice.com.objects.BasePage;
public class SelectProductBestSellerPage extends BasePage {
	@FindBy(css="#selectProductSort")
	WebElement btnselectProductSort;
	@FindBy(css=".replace-2x.img-responsive")
	WebElement MovePicture;
	@FindBy(css="[title='Add to cart']>span")
	WebElement btnAddToCart;
	@FindBy(css=".btn.btn-default.button.button-medium>span")
	WebElement btnProceedCheckOut;
	public SelectProductBestSellerPage(WebDriver driver) {
		super(driver);
	}
	public void select(){
		Select s = new Select(btnselectProductSort);
		s.selectByValue("price:asc");
	}
	public void ToTheCart (int pos) {
		sleep(1000);
		List<WebElement> rows = driver.findElements(By.cssSelector("[title='Printed Dress']>img"));
		Actions actions = new Actions(driver);
		actions.moveToElement(rows.get(pos)).build().perform();
		sleep(1000);
		List <WebElement> list = driver.findElements(By.cssSelector("[title='Add to cart']>span"));
		click(list.get(pos));
		sleep(1000);
	}
	public void ProceedToCheckOut () {
		click(btnProceedCheckOut);
	}
}