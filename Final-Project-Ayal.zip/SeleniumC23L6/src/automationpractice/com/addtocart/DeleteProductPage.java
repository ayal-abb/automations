package automationpractice.com.addtocart;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import automationpractice.com.objects.BasePage;
public class DeleteProductPage extends BasePage {
	@FindBy(css=".icon-trash")
	WebElement clickDeleteProduct;
	@FindBy(css=".alert.alert-warning")
	WebElement errorMsgShoppingCartSummary ;
	@FindBy(css=".icon-plus")
	WebElement AddQuantityInTheProduct ;
	public DeleteProductPage(WebDriver driver) {
		super(driver);
	}
	public void DeleteProduct () {
		click(clickDeleteProduct);
	}
	public String errorMsg () {
		return getText(errorMsgShoppingCartSummary);   
	}
	public void AddQuantityInTheProduc() {
		click(AddQuantityInTheProduct);
	}
}