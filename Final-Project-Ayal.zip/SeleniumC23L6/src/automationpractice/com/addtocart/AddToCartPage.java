package automationpractice.com.addtocart;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.ClickAction;
import org.openqa.selenium.interactions.ClickAndHoldAction;
import org.openqa.selenium.support.FindBy;
import automationpractice.com.objects.BasePage;
import automationpractice.com.tests.BaseTest;
public class AddToCartPage extends BasePage {
	@FindBy(css=".replace-2x.img-responsive")
	WebElement btnAddToCart ;
	@FindBy(css="[title='Add to cart']>span")
	WebElement btnToCart ;
	@FindBy(css=".btn.btn-default.button.button-medium>span")
	WebElement btnProccedToCheckOut ;
	public AddToCartPage(WebDriver driver) {
		super(driver);
	}
	// add item and continue shopping
	public void ToCart (int pos) {
		sleep(1000);
		List<WebElement> rows = driver.findElements(By.cssSelector(".replace-2x.img-responsive"));
		Actions actions = new Actions(driver);
		actions.moveToElement(rows.get(pos)).build().perform();
		sleep(1000);
		List <WebElement> list = driver.findElements(By.cssSelector("[title='Add to cart']>span"));
		click(list.get(pos));
		sleep(1000);
		click(btnProccedToCheckOut);
	}	
	public void ProccedToCheckOut () {
		click(btnProccedToCheckOut);
	}
}