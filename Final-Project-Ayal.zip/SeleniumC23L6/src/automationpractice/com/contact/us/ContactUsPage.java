package automationpractice.com.contact.us;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import automationpractice.com.objects.BasePage;
public class ContactUsPage extends BasePage {
	@FindBy(css= "#contact-link")
	WebElement btnContactUs;
	public ContactUsPage(WebDriver driver) {
		super(driver);
	}
	public void ClickOnContactUs() {
		click(btnContactUs);	
	}
}