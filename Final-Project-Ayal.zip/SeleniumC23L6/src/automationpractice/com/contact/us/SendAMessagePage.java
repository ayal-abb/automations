package automationpractice.com.contact.us;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;
import automationpractice.com.objects.BasePage;
public class SendAMessagePage extends BasePage {
	@FindBy(css = "#id_contact")
	WebElement selContact;
	@FindBy(css = "[name='from']")
	WebElement fdemail;
	@FindBy(css = "#id_order")
	WebElement fdOrderReference;
	@FindBy(css = "#message")
	WebElement fdMessage;
	@FindBy(css = "#submitMessage")
	WebElement btnClickSend;
	@FindBy(css = ".alert.alert-danger")
	WebElement ErrorMsgSend;
	@FindBy(css = ".alert.alert-success")
	WebElement errorMsgCreateAccount;
	public SendAMessagePage(WebDriver driver) {
		super(driver);
	}
	public void Choose() {
		Select s = new Select(selContact);
		s.selectByIndex(1);
	}
	public void email(String email) {
		fillText(fdemail, email);
	}
	public void OrderReference(String order) {
		fillText(fdOrderReference, order);
	}
	public void Message(String message) {
		fillText(fdMessage, message);
	}
	public void btnClickSend() {
		click(btnClickSend);
	}
	public String ErrorMsgSend() {
		return getText(ErrorMsgSend);
	}	
	public String errorMsg() {
		return getText(errorMsgCreateAccount);
	}
}